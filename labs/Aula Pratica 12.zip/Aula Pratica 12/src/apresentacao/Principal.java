package apresentacao;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.GridLayout;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Principal {
	
	public static void main(String[] args) {
		//TelaPrincipal tela = new TelaPrincipal();
		TelaPrincipalv2 tela = new TelaPrincipalv2();
		//tela.setVisible(true);
		
/*		JFrame tela = new JFrame();
		Container c = tela.getContentPane();
		
		JPanel painel = new JPanel();
		painel.setLayout(new GridLayout(1,1));
		painel.add(new JLabel("Ol� Mundo!!"));
		c.add(painel,BorderLayout.CENTER);
		tela.setSize(400, 300);
		//tela.pack();
		tela.setVisible(true);
		*/
	}

}
