package apresentacao;

import java.util.List;


import javax.swing.table.AbstractTableModel;
import dados.Pessoa;

public class PessoaTableModel extends AbstractTableModel {

	List<Pessoa> pessoas;
	private String[] colunas = {"CPF", "Nome", "Endere�o",
			"Cidade","Estado"};
	
	@Override
	public int getColumnCount() {
		return colunas.length;
	}

	@Override
	public int getRowCount() {
		return pessoas.size();
	}
	
	public Class getColumnClass(int c) {
        return getValueAt(0, c).getClass();
    }
	
	public boolean isCellEditable(int linha, int coluna) {
	    if (coluna < 1) {
	    	return false;
	    } 
	    else {
	    	return true;
	    }
	}
	
	public void setValueAt(Object valor, int linha, int coluna) {
		
		switch (coluna) {
		case 0:
			pessoas.get(linha).setCpf((int)valor);
			break;
		case 1:
			pessoas.get(linha).setNome((String)valor);
			break;
		case 2:
			pessoas.get(linha).setEndereco((String)valor);
			break;
		case 3:
			pessoas.get(linha).setCidade((String)valor);
			break;
		case 4:
			pessoas.get(linha).setEstado((String)valor);
			break;
		}
	    fireTableCellUpdated(linha, coluna);
	}

	@Override
	public Object getValueAt(int linha, int coluna) {
        switch(coluna){
	        case 0: return pessoas.get(linha).getCpf();
	        case 1: return pessoas.get(linha).getNome();
	        case 2: return pessoas.get(linha).getEndereco();
	        case 3: return pessoas.get(linha).getCidade();
	        case 4: return pessoas.get(linha).getEstado();
        }   
        return null;
	}

    public String getColumnName(int num){
        return this.colunas[num];
    }
 
	public PessoaTableModel(List<Pessoa> p) {
		pessoas = p;
		
		
	}
}
