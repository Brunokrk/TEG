package apresentacao;

public class Principal {

	public static void main(String[] args) {
		TelaPrincipal tela = new TelaPrincipal();
		tela.setVisible(true);
	}
	
}
